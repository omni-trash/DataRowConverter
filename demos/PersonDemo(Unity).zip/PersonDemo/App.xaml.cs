﻿using System.Windows;
using CommonServiceLocator;
using Unity;
using Unity.ServiceLocation;

namespace PersonDemo
{
    using Data;
    using Interfaces;

    /// <summary>
    /// Interaktionslogik für "App.xaml"
    /// </summary>
    public partial class App : Application
    {
        public App()
        {
            // IoC Container
            UnityContainer container = new UnityContainer();
            container.RegisterType<IPersonRepository, PersonRepository>();

            // Service Locator
            UnityServiceLocator locator = new UnityServiceLocator(container);
            ServiceLocator.SetLocatorProvider(() => locator);
        }

        /// <summary>
        /// Helper, resolves from Service Locator
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static T Resolve<T>()
            where T : class
        {
            return (ServiceLocator.IsLocationProviderSet ? ServiceLocator.Current.GetInstance<T>() : null);
        }
    }
}
