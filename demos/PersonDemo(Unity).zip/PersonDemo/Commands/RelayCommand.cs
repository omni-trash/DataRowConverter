﻿using System;
using System.Windows.Input;

namespace PersonDemo.Commands
{
    /// <summary>
    /// Relay Command Implementation
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class RelayCommand<T> : ICommand
    {
        private readonly Action<T> _execute;
        private readonly Predicate<T> _canExecute;

        /// <summary>
        /// <see cref="ICommand.CanExecuteChanged"/>
        /// <inheritdoc/>
        /// </summary>
        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        /// <summary>
        /// Initializes a new <see cref="RelayCommand{T}"/> instance
        /// </summary>
        /// <param name="execute"></param>
        public RelayCommand(Action<T> execute)
            : this(execute, null)
        {
        }

        /// <summary>
        /// Initializes a new <see cref="RelayCommand{T}"/>instance
        /// </summary>
        /// <param name="execute">The execute action</param>
        /// <param name="canExecute">A predicate to check for execute</param>
        public RelayCommand(Action<T> execute, Predicate<T> canExecute)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute ?? ((T) => true);
        }

        /// <summary>
        /// Returns true if the command can be execute
        /// </summary>
        /// <param name="parameter"></param>
        /// <returns></returns>
        bool ICommand.CanExecute(object parameter)
        {
            return _canExecute((T)parameter);
        }

        /// <summary>
        /// Executes the command
        /// </summary>
        /// <param name="parameter">The parameter to use</param>
        public void Execute(object parameter)
        {
            _execute.Invoke((T)parameter);
            CommandManager.InvalidateRequerySuggested();
        }
    }
}
