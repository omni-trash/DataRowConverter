﻿using System.ComponentModel;
using System.Windows;

namespace PersonDemo
{
    /// <summary>
    /// Some useful definitions
    /// </summary>
    public static class Defines
    {
        /// <summary>
        /// Is true if we are in design mode (VS Designer)
        /// </summary>
        public static bool IsDesignMode { get; } = DesignerProperties.GetIsInDesignMode(new DependencyObject());
    }
}
