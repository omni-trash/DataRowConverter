﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Input;

namespace PersonDemo.ViewModels
{
    using Commands;
    using Interfaces;
    using Models;

    /// <summary>
    /// Sample
    /// </summary>
    public class MainViewModel : INotifyPropertyChanged
    {
        // Data Access
        private readonly IPersonRepository _repository;

        public ObservableCollection<Person> Persons { get; private set; } = new ObservableCollection<Person>();

        public event PropertyChangedEventHandler PropertyChanged;

        // First Name Property with backing field
        private string _firstName;
        public string FirstName
        {
            get => _firstName;
            set
            {
                if (_firstName != value)
                {
                    _firstName = value;
                    UpdateList();
                    PropertyChanged.Invoke(this, new PropertyChangedEventArgs(nameof(FirstName)));
                }
            }
        }

        // Last Name Property with backing field
        private string _lastName;
        public string LastName
        {
            get => _lastName;
            set
            {
                if (_lastName != value)
                {
                    _lastName = value;
                    UpdateList();
                    PropertyChanged.Invoke(this, new PropertyChangedEventArgs(nameof(LastName)));
                }
            }
        }

        // Clear Button Commands
        public ICommand ClearFirstNameCommand { get; private set; }
        public ICommand ClearLastNameCommand  { get; private set; }

        /// <summary>
        /// Initializes a new instance
        /// </summary>
        public MainViewModel() : this(App.Resolve<IPersonRepository>())
        {
        }

        /// <summary>
        /// Initializes a new instance
        /// </summary>
        /// <param name="repository"></param>
        public MainViewModel(IPersonRepository repository)
        {
            if (Defines.IsDesignMode)
            {
                return;
            }

            _repository = repository ?? throw new ArgumentNullException(nameof(repository));

            ClearFirstNameCommand = new RelayCommand<object>((p) => FirstName = string.Empty);
            ClearLastNameCommand  = new RelayCommand<object>((p) => LastName  = string.Empty);
        }

        /// <summary>
        /// Search person
        /// </summary>
        /// <returns></returns>
        private void UpdateList()
        {
            List<Person> list = _repository.FindPerson(_firstName, _lastName);
            Persons.Clear();
            list.ForEach(Persons.Add);
        }
    }
}
