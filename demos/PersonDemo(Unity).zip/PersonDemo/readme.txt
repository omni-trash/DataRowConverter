﻿PersonDemo - Demo Project for DataRowConverter (https://github.com/omni-trash/DataRowConverter)

The files to subject are in the Data folder.

Required packages in this demo for IoC
- Unity.Container
- Unity.ServiceLocation


1.21.9.11
- first release
