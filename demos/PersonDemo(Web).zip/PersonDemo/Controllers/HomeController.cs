﻿using System.Web.Mvc;

namespace PersonDemo.Controllers
{
    [RoutePrefix("")]
    public class HomeController : Controller
    {
        [Route("")]
        public ActionResult Index()
        {
            ViewBag.Title = "Personensuche (random data)";
            return View();
        }
    }
}
