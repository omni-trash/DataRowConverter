﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace PersonDemo.Controllers
{
    using Interfaces;
    using Models;

    [RoutePrefix("api/values")]
    public class ValuesController : ApiController
    {
        private readonly IPersonRepository _repository;

        public ValuesController(IPersonRepository repository)
        {
            _repository = repository ?? throw new ArgumentNullException(nameof(repository));
        }

        // GET api/values
        [HttpGet]
        [Route("persons")]
        public IEnumerable<Person> Get(string vorname, string nachname)
        {
            return _repository.FindPerson(vorname, nachname);
        }
   }
}
