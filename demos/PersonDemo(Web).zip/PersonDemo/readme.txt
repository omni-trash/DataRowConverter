﻿PersonDemo - Demo Project for DataRowConverter (https://github.com/omni-trash/DataRowConverter)

The files to subject are in the Data folder.

Required packages in this demo for IoC / DI
- Unity
- Unity.Mvc
- Unity.AspNet.WebApi

1.21.9.18
- first release (MVC + WebApi)
