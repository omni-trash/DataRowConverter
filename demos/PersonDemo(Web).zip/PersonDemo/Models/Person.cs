﻿using System;
using System.ComponentModel.DataAnnotations;

namespace PersonDemo.Models
{
    /// <summary>
    /// Person Data Model
    /// </summary>
    public class Person
    {
        /// <summary>
        /// First Name
        /// </summary>
        public string Vorname { get; set; }

        /// <summary>
        /// Last Name
        /// </summary>
        public string Nachname { get; set; }

        /// <summary>
        /// Birthday
        /// </summary>
        [DisplayFormat(DataFormatString = "{0:dd.MM.yyyy}")]
        public DateTime? Geburtstag { get; set; }

        /// <summary>
        /// Country
        /// </summary>
        public string Land { get; set; }

        /// <summary>
        /// Weight
        /// </summary>
        [DisplayFormat(DataFormatString = "{0:N1} kg")]
        public double? Gewicht { get; set; }
    }
}

