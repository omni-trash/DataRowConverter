﻿using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace PersonDemo.Data
{
    using Interfaces;
    using Models;

    /// <summary>
    /// Person Repository with Table Adapter
    /// </summary>
    public class PersonRepository : IPersonRepository
    {
        /// <summary>
        /// Finds person by first and last name
        /// </summary>
        /// <param name="vorname"></param>
        /// <param name="nachname"></param>
        /// <returns></returns>
        public List<Person> FindPerson(string vorname, string nachname)
        {
            vorname = vorname?.Trim();
            nachname = nachname?.Trim();

            if (string.IsNullOrWhiteSpace(vorname) && string.IsNullOrWhiteSpace(nachname))
            {
                // nothing to search, return empty list
                return new List<Person>();
            }

            using (BackendTableAdapters.PersonTableAdapter adapter = new BackendTableAdapters.PersonTableAdapter())
            {
                return adapter.FindPerson(vorname, nachname).Select(DataRowConverter<Person>.Cast).ToList();
            }
        }
    }
}
