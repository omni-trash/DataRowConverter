﻿using System;
using System.Windows;
using Microsoft.Extensions.DependencyInjection;

namespace PersonDemo
{
    using Data;
    using Interfaces;

    /// <summary>
    /// Interaktionslogik für "App.xaml"
    /// </summary>
    public partial class App : Application
    {
        private static IServiceProvider Services { get; set; }

        public App()
        {
            ServiceCollection services = new ServiceCollection();
            services.AddSingleton<IPersonRepository, PersonRepository>();
            Services = services.BuildServiceProvider();
        }

        /// <summary>
        /// Helper, resolves from Service Locator
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static T Resolve<T>()
            where T : class
        {
            return Services?.GetService<T>();
        }
    }
}
