﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace PersonDemo
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            VersionLabel.Content = $"v{System.Reflection.Assembly.GetExecutingAssembly().GetName().Version}";
        }

        /// <summary>
        /// When columns are auto generated we need to set some UI stuff through Attributes (see Models)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DataGrid_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            DisplayFormatAttribute displayFormat = (e.PropertyDescriptor as PropertyDescriptor)?.Attributes.OfType<DisplayFormatAttribute>().FirstOrDefault();

            if (displayFormat != null && !string.IsNullOrWhiteSpace(displayFormat.DataFormatString))
            {
                (e.Column as DataGridTextColumn).Binding.StringFormat = displayFormat.DataFormatString;
                (e.Column as DataGridTextColumn).Binding.TargetNullValue = string.Empty;
            }
        }
    }
}
