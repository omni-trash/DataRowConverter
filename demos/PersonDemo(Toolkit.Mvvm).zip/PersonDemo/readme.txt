﻿PersonDemo - Demo Project for DataRowConverter (https://github.com/omni-trash/DataRowConverter)

The files to subject are in the Data folder.

Required packages
- Microsoft.Extensions.DependencyInjection
- Microsoft.Toolkit.Mvvm

1.21.9.11
- first release
