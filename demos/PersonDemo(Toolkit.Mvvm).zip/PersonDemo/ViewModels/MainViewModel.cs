﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Input;
using Microsoft.Toolkit.Mvvm.ComponentModel;
using Microsoft.Toolkit.Mvvm.Input;

namespace PersonDemo.ViewModels
{
    using Interfaces;
    using Models;

    /// <summary>
    /// Sample
    /// </summary>
    public class MainViewModel : ObservableObject
    {
        // Data Access
        private readonly IPersonRepository _repository;

        public ObservableCollection<Person> Persons { get; private set; } = new ObservableCollection<Person>();

        // First Name Property with backing field
        private string _firstName;
        public string FirstName
        {
            get => _firstName;
            set => SetProperty(ref _firstName, value);
        }

        // Last Name Property with backing field
        private string _lastName;
        public string LastName
        {
            get => _lastName;
            set => SetProperty(ref _lastName, value);
        }

        // Clear Button Commands
        public ICommand ClearFirstNameCommand { get; private set; }
        public ICommand ClearLastNameCommand  { get; private set; }

        /// <summary>
        /// Initializes a new instance
        /// </summary>
        public MainViewModel() : this(App.Resolve<IPersonRepository>())
        {
        }

        /// <summary>
        /// Initializes a new instance
        /// </summary>
        /// <param name="repository"></param>
        public MainViewModel(IPersonRepository repository)
        {
            if (Defines.IsDesignMode)
            {
                return;
            }

            _repository = repository ?? throw new ArgumentNullException(nameof(repository));

            ClearFirstNameCommand = new RelayCommand<object>((p) => FirstName = string.Empty);
            ClearLastNameCommand  = new RelayCommand<object>((p) => LastName  = string.Empty);

            PropertyChanged += MainViewModel_PropertyChanged;
        }

        private void MainViewModel_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(FirstName) || e.PropertyName == nameof(LastName))
            {
                UpdateList();
            }
        }

        /// <summary>
        /// Search person
        /// </summary>
        /// <returns></returns>
        private void UpdateList()
        {
            List<Person> list = _repository.FindPerson(_firstName, _lastName);
            Persons.Clear();
            list.ForEach(Persons.Add);
        }
    }
}
