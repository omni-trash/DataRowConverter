﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace PersonDemo.ViewModels
{
    using Interfaces;
    using Models;

    /// <summary>
    /// Sample
    /// </summary>
    public class MainViewModel : INotifyPropertyChanged
    {
        // Data Access
        private readonly IPersonRepository _repository;

        // Persons Property with backing field
        BindingList<Person> _persons = new BindingList<Person>();
        public BindingList<Person> Persons
        {
            get => _persons;
            set
            {
                if (_persons != value)
                {
                    _persons = value;
                    PropertyChanged.Invoke(this, new PropertyChangedEventArgs(nameof(Person)));
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        // First Name Property with backing field
        private string _firstName;
        public string FirstName
        {
            get => _firstName;
            set
            {
                if (_firstName != value)
                {
                    _firstName = value;
                    PropertyChanged.Invoke(this, new PropertyChangedEventArgs(nameof(FirstName)));
                }
            }
        }

        // Last Name Property with backing field
        private string _lastName;
        public string LastName
        {
            get => _lastName;
            set
            {
                if (_lastName != value)
                {
                    _lastName = value;
                    PropertyChanged.Invoke(this, new PropertyChangedEventArgs(nameof(LastName)));
                }
            }
        }

        /// <summary>
        /// Initializes a new instance
        /// </summary>
        public MainViewModel() : this(App.Resolve<IPersonRepository>())
        {
        }

        /// <summary>
        /// Initializes a new instance
        /// </summary>
        /// <param name="repository"></param>
        public MainViewModel(IPersonRepository repository)
        {
            _repository = repository ?? throw new ArgumentNullException(nameof(repository));

            PropertyChanged += MainViewModel_PropertyChanged;
        }

        private void MainViewModel_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(FirstName) || e.PropertyName == nameof(LastName))
            {
                UpdateList();
            }
        }

        /// <summary>
        /// Clear First Name Button
        /// </summary>
        public void ClearFirstName()
        {
            FirstName = string.Empty;
        }

        /// <summary>
        /// Clear Last Name Button
        /// </summary>
        public void ClearLastName()
        {
            LastName = string.Empty;
        }

        /// <summary>
        /// Search person
        /// </summary>
        /// <returns></returns>
        private void UpdateList()
        {
            List<Person> list = _repository.FindPerson(_firstName, _lastName);
            BindingList<Person> bindingListPersons = new BindingList<Person>(list);
            Persons = bindingListPersons;
        }
    }
}
