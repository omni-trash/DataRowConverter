﻿using System;

namespace PersonDemo
{
    static class Program
    {
        /// <summary>
        /// Der Haupteinstiegspunkt für die Anwendung.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // Moved to App
            new App().Run();
        }
    }
}
