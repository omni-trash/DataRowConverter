﻿using System;
using System.Windows.Forms;
using Microsoft.Extensions.DependencyInjection;

namespace PersonDemo
{
    using Data;
    using Interfaces;

    public class App
    {
        private static IServiceProvider Services { get; set; }

        public App()
        {
            ServiceCollection services = new ServiceCollection();
            services.AddSingleton<IPersonRepository, PersonRepository>();
            Services = services.BuildServiceProvider();
        }

        /// <summary>
        /// Helper, resolves from Service Locator
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static T Resolve<T>()
            where T : class
        {
            return Services?.GetService<T>();
        }

        public void Run()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
