﻿using System;
using System.Windows.Forms;

namespace PersonDemo
{
    using ViewModels;

    public partial class MainForm : Form
    {
        public MainViewModel ViewModel
        {
            get => ViewModelBinding.DataSource as MainViewModel;
            set => ViewModelBinding.DataSource = value;
        }

        public MainForm()
        {
            InitializeComponent();
            versionLabel.Text = $"v{System.Reflection.Assembly.GetExecutingAssembly().GetName().Version}";
            ViewModel = new MainViewModel();
        }

        private void clearFirstNameButton_Click(object sender, EventArgs e)
        {
            ViewModel?.ClearFirstName();
        }

        private void clearLastNameButton_Click(object sender, EventArgs e)
        {
            ViewModel?.ClearLastName();
        }
    }
}
