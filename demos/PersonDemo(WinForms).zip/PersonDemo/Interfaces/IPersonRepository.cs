﻿using System.Collections.Generic;

namespace PersonDemo.Interfaces
{
    using Models;

    /// <summary>
    /// Person Repository (Data Access)
    /// </summary>
    public interface IPersonRepository
    {
        /// <summary>
        /// Finds person by first and last name
        /// </summary>
        /// <param name="vorname"></param>
        /// <param name="nachname"></param>
        /// <returns></returns>
        List<Person> FindPerson(string vorname, string nachname);
    }
}
